HOW TO BUILD YOUR APK
======================

STEP 1 — Clean out your Codespace
----------------------------------
In the Codespaces file Explorer, select and delete ALL existing files/folders
(build.sh, app, build.gradle, settings.gradle, local.properties, strings.xml,
AndroidManifest.xml, MainActivity.java, activity_main.xml, icon_1024_master.png,
everything) so the folder is completely empty.

STEP 2 — Upload this zip
--------------------------
In the Explorer, tap "Upload..." (or drag the zip in) and upload
lottery-srilanka-project.zip into the empty folder.

STEP 3 — Extract it
---------------------
In the terminal, type:

    unzip lottery-srilanka-project.zip -d .
    rm lottery-srilanka-project.zip

STEP 4 — IMPORTANT: set your Netlify link
-------------------------------------------
Open this file in the editor:

    app/src/main/java/com/lotterysrilanka/app/MainActivity.java

Find this line near the top:

    private static final String APP_URL = "https://YOUR-NETLIFY-LINK.netlify.app";

Replace YOUR-NETLIFY-LINK with your real Netlify address, then save.

STEP 5 — Install Gradle (one line, uses apt instead of a slow direct download)
---------------------------------------------------------------------------------
In the terminal, type:

    sudo apt-get update -y && sudo apt-get install -y gradle openjdk-17-jdk unzip

Wait for it to finish.

STEP 6 — Install the Android SDK
-----------------------------------
Copy-paste this whole block into the terminal and press Enter:

    mkdir -p ~/android-sdk/cmdline-tools
    cd ~/android-sdk/cmdline-tools
    curl -o cmdline-tools.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
    unzip -q cmdline-tools.zip && mv cmdline-tools latest
    export ANDROID_HOME=~/android-sdk
    export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin
    yes | sdkmanager --licenses > /dev/null
    sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"

STEP 7 — Build the APK
-------------------------
Go back to your project's root folder and run:

    cd /workspaces/*
    export ANDROID_HOME=~/android-sdk
    export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools
    echo "sdk.dir=$ANDROID_HOME" > local.properties
    gradle wrapper
    ./gradlew assembleDebug

This takes 5-10 minutes. Watch for "BUILD SUCCESSFUL" at the end.

STEP 8 — Find your APK
-------------------------
    ls app/build/outputs/apk/debug/

You'll see app-debug.apk there. Tap it in the Explorer, then use the
download/share icon to save it to your iPhone, then send it to your
Android phone (AirDrop, email, Google Drive, WhatsApp to yourself).

IF SOMETHING FAILS
--------------------
Type out (don't just photograph) the last 5-10 lines of red error text
and send it in chat — that's much easier for me to read than a photo.
